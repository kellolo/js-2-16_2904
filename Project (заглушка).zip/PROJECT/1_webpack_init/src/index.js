import app from './public/js/main.js'
import './public/style/style.css'
import './public/style/normalize.css'

app()